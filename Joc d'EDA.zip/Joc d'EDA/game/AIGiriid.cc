#include "Player.hh"


/**
 * Write the name of your player and save this file
 * with the same name and .cc extension.
 */
#define PLAYER_NAME Giriid


struct PLAYER_NAME : public Player {

  /**
   * Factory: returns a new instance of this class.
   * Do not modify this function.
   */
  static Player* factory () {
    return new PLAYER_NAME;
  }


  /**
   * Types and attributes for your player can be defined here.
   */

    typedef vector<vector<char>> Mapa;
    typedef vector<int> VI;
    
    bool pos_valida (Pos p){
        if (not pos_ok(p)) return false;
        else if (cell(p).type == WALL) return false;
        //else if (cell(p).city_id != -1 and city_owner(cell(p).city_id) == me()) return false;
        else return true;
    }

    bool ciudad_conquistar(Pos p) {
        if (cell(p).city_id != -1 and city_owner(cell(p).city_id) == me()) return false;
        else if (cell(p).city_id == -1) return false;
        return true;
    }

    bool camino_conquistar(Pos p) {
        if (cell(p).path_id != -1 and path_owner(cell(p).path_id) == me()) return false;
        else if (cell(p).path_id == -1) return false;
        return true;
    }

    bool debilitar_pokemon(Pos p,int dist) {
        if (cell(p).unit_id == -1) return false;
        if (cell(p).unit_id != -1 and unit(cell(p).unit_id).player  == me()) return false;
        if(dist >= 3) return false;
        return true;
    }

    char dirtochar(Dir d) {
        if (d == TOP) return 't';
        else if (d == BOTTOM) return 'b';
        else if (d == LEFT) return 'l';
        else if (d == RIGHT) return 'r';
        return 'v';
    }

    Dir invchartodir(char c) {
        if (c == 't') return BOTTOM;
        else if (c == 'b') return TOP;
        else if (c == 'l') return RIGHT;
        else if (c == 'r') return LEFT;
        return NONE;
    }

    Dir chartodir(char c) {
        if (c == 'b') return BOTTOM;
        else if (c == 't') return TOP;
        else if (c == 'r') return RIGHT;
        else if (c == 'l') return LEFT;
        return NONE;
    }

    Dir bfs (Unit u,int dist) {
        queue<Pos> Q;
        Mapa vis (rows(), vector<char>(cols(), '.'));
        Q.push(u.pos);
        vis[u.pos.i][u.pos.j] = 'v';
        //anado pos ini Q
        //marcados pos ini vis
        while(not Q.empty()){
            Pos act = Q.front();
            Q.pop();
            dist+=1;
            for(int i = 0; i < 4; ++i) {
                Pos ps = act + Dir(i);
                if (pos_valida(ps) and vis[ps.i][ps.j] == '.') {
                    if(debilitar_pokemon(ps,dist)){
                        if (act == u.pos) return Dir(i);
                        else {
                            Dir d = invchartodir(vis[act.i][act.j]);
                            while (act+d != u.pos) {
                                act += d;
                                d = invchartodir(vis[act.i][act.j]);
                            }
                            return chartodir(vis[act.i][act.j]);
                        }
                    }
                    else if(ciudad_conquistar(ps) or camino_conquistar(ps)){
                        if (act == u.pos) return Dir(i);
                        else {
                            Dir d = invchartodir(vis[act.i][act.j]);
                            while (act+d != u.pos) {
                                act += d;
                                d = invchartodir(vis[act.i][act.j]);
                            }
                            return chartodir(vis[act.i][act.j]);
                        }
                    }
                    else {//sino esta vacia
                        Q.push(ps);
                        char c = dirtochar(Dir(i));
                        vis[ps.i][ps.j] = c;
                    }
                }
            }
        }
        return NONE;
    }

  /**
   * Play method, invoked once per each round.
   */
  virtual void play () {
      VI U = my_units(me()); // Get the id's of my units.
	  int n = U.size();
	  VI perm = random_permutation(n);
	  for (int i = 0; i < n; ++i) {
			
		  // We process the units in random order.
		  int id = U[perm[i]];
          int dist=0;
		  Unit u = unit(id);
          Dir d = bfs(u,dist);
          move(id, d);
      }
	
  }

};

/**
 * Do not modify the following line.
 */
RegisterPlayer(PLAYER_NAME);
